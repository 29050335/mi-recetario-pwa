import React, { useState } from 'react';
import { db } from '../firebase';
import { collection, addDoc } from 'firebase/firestore';

const RecipeForm = ({ onSaveRecipe }) => {
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');

  const handleSave = async (e) => {
    e.preventDefault();
    const newRecipe = { name, description };
    // Guardar en Firestore
    await addDoc(collection(db, 'recipes'), newRecipe);
    // Guardar en LocalStorage
    const savedRecipes = JSON.parse(localStorage.getItem('recipes')) || [];
    savedRecipes.push(newRecipe);
    localStorage.setItem('recipes', JSON.stringify(savedRecipes));
    onSaveRecipe(newRecipe);
  };

  return (
    <form onSubmit={handleSave}>
      <input
        type="text"
        placeholder="Nombre de la receta"
        value={name}
        onChange={(e) => setName(e.target.value)}
      />
      <textarea
        placeholder="Descripción"
        value={description}
        onChange={(e) => setDescription(e.target.value)}
      ></textarea>
      <button type="submit">Guardar Receta</button>
    </form>
  );
};

export default RecipeForm;
