import { openDB } from "idb";

const DATABASE_NAME = "RecipesDB";
const STORE_NAME = "recipes";

// Crear o abrir la base de datos
const getDB = async () => {
  return await openDB(DATABASE_NAME, 1, {
    upgrade(db) {
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        db.createObjectStore(STORE_NAME, { keyPath: "id", autoIncrement: true });
      }
    },
  });
};

// Guardar receta
export const saveRecipeToIndexedDB = async (recipe) => {
  const db = await getDB();
  const tx = db.transaction(STORE_NAME, "readwrite");
  await tx.store.add(recipe);
  await tx.done;
  console.log("Receta guardada en IndexedDB:", recipe);
};

// Obtener todas las recetas
export const getRecipesFromIndexedDB = async () => {
  const db = await getDB();
  const tx = db.transaction(STORE_NAME, "readonly");
  const allRecipes = await tx.store.getAll();
  console.log("Recetas recuperadas de IndexedDB:", allRecipes);
  return allRecipes;
};
