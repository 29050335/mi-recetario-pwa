import { getRecipesFromIndexedDB } from "./indexedDB";
import { db } from "./firebase";  // Asegúrate de que este archivo esté configurado correctamente
import { collection, addDoc } from "firebase/firestore";

// Función para sincronizar recetas de IndexedDB con Firebase
export const syncWithFirebase = async () => {
  const recipes = await getRecipesFromIndexedDB();

  for (const recipe of recipes) {
    try {
      // Guarda cada receta en Firebase
      await addDoc(collection(db, "recipes"), recipe);
      console.log("Receta sincronizada con Firebase:", recipe);
    } catch (error) {
      console.error("Error sincronizando receta con Firebase:", error);
    }
  }
};
