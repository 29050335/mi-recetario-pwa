import React, { useState, useEffect } from 'react';
import RecipeCard from '../components/RecipeCard';
import RecipeForm from '../components/RecipeForm';
import { db } from '../firebase';
import { collection, getDocs } from 'firebase/firestore';

const Home = () => {
  const [recipes, setRecipes] = useState([]);
  const [isFormVisible, setFormVisible] = useState(false);

  useEffect(() => {
    const loadRecipes = async () => {
      // Primero carga desde LocalStorage
      const localRecipes = JSON.parse(localStorage.getItem('recipes')) || [];
      setRecipes(localRecipes);

      // Luego sincroniza con Firestore
      const querySnapshot = await getDocs(collection(db, 'recipes'));
      const firebaseRecipes = querySnapshot.docs.map(doc => doc.data());
      setRecipes(prevRecipes => [...prevRecipes, ...firebaseRecipes]);
    };

    loadRecipes();
  }, []);

  const handleSaveRecipe = (recipe) => {
    setRecipes((prev) => [...prev, recipe]);
  };

  return (
    <div>
      <button onClick={() => setFormVisible(true)}>Crear Receta</button>
      {isFormVisible && <RecipeForm onSaveRecipe={handleSaveRecipe} />}
      <div>
        {recipes.map((recipe, index) => (
          <RecipeCard key={index} recipe={recipe} />
        ))}
      </div>
    </div>
  );
};

export default Home;
