import React from 'react';
import './RecipeCard.css';

const RecipeCard = ({ recipe }) => {
  return (
    <div className="recipe-card">
      {/* Mostrar la imagen si existe */}
      {recipe.image && (
        <div className="recipe-image">
          <img
            src={recipe.image}
            alt={`Imagen de ${recipe.name}`}
            className="recipe-img"
          />
        </div>
      )}

      <div className="recipe-content">
        <h3 className="recipe-title">{recipe.name}</h3>
        <p className="recipe-author"><strong>Autor:</strong> {recipe.author}</p>

        <h4 className="section-title">Ingredientes:</h4>
        <ul className="ingredients-list">
          {recipe.ingredients?.map((ingredient, index) => (
            <li key={index} className="ingredient-item">{ingredient}</li>
          ))}
        </ul>

        <h4 className="section-title">Pasos:</h4>
        <ol className="steps-list">
          {recipe.steps?.map((step, index) => (
            <li key={index} className="step-item">{step}</li>
          ))}
        </ol>
      </div>
    </div>
  );
};

export default RecipeCard;
