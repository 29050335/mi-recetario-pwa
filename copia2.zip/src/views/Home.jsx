import React, { useState, useEffect } from 'react';
import RecipeCard from '../components/RecipeCard';
import RecipeForm from '../components/RecipeForm';
import { db } from '../firebase';
import { collection, getDocs } from 'firebase/firestore';
import { getRecipesFromIndexedDB, saveRecipeToIndexedDB } from '../indexedDB';

const Home = () => {
  const [recipes, setRecipes] = useState([]);
  const [isFormVisible, setFormVisible] = useState(false);

  useEffect(() => {
    const loadRecipes = async () => {
      // Cargar recetas desde IndexedDB
      const localRecipes = await getRecipesFromIndexedDB();
      setRecipes(localRecipes);

      // Sincronizar con Firestore
      const querySnapshot = await getDocs(collection(db, 'recipes'));
      const firebaseRecipes = querySnapshot.docs.map((doc) => doc.data());

      // Filtrar recetas duplicadas (verificando nombre)
      const uniqueRecipes = firebaseRecipes.filter((firebaseRecipe) =>
        !localRecipes.some(localRecipe =>
          localRecipe.name === firebaseRecipe.name &&
          localRecipe.author === firebaseRecipe.author &&
          JSON.stringify(localRecipe.ingredients) === JSON.stringify(firebaseRecipe.ingredients) &&
          JSON.stringify(localRecipe.steps) === JSON.stringify(firebaseRecipe.steps)
        )
      );
      

      // Guardar recetas únicas en IndexedDB
      uniqueRecipes.forEach((recipe) => saveRecipeToIndexedDB(recipe));

      // Actualizar la lista de recetas sin duplicados
      setRecipes((prevRecipes) => [...prevRecipes, ...uniqueRecipes]);
    };

    loadRecipes();
  }, []);

  const handleSaveRecipe = (recipe) => {
    setRecipes((prev) => [...prev, recipe]);
  };

  return (
    <div>
      <button onClick={() => setFormVisible(true)}>Crear Receta</button>
      {isFormVisible && <RecipeForm onSaveRecipe={handleSaveRecipe} />}
      <div>
        {recipes.map((recipe, index) => (
          <RecipeCard key={index} recipe={recipe} />
        ))}
      </div>
    </div>
  );
};

export default Home;
